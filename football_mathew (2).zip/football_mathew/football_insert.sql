Insert into Football_league values(1,'FIFA',2017);
Insert into Football_league values(2,'UEFA',2021);
Insert into Football_league values(3,'EFL',2021);

Insert into Football_team values(101,'Manchester','Ole Gunner','Harry Maguire',11,'Manchester United',1);
Insert into Football_team values(102,'Liverpool','Jurgen Klopp','Jordan henderson',11,'UEFA',2);
Insert into Football_team values(103,'Chelsea','Thomas Tuchel','Cesar',11,'UEFA',3);

Insert into player values(18,'Virat','Expert','Center',101);
Insert into player values(21,'Raina','Expert','quarter back',102);
Insert into player values(99,'Warner','Expert','Fullback',103);

Insert into Game_played values(21,'Chelsea','12/09/2021','won',101);
Insert into Game_played values(22,'Manchester United','14/09/2021','lost',102);
Insert into Game_played values(23,'Liverpool','16/09/2021','draw',103);